#!/bin/bash
set -e

MANAGER="${WAZUH_MANAGER:-wazuh.manager}"
echo "[*] Pointing agent at manager: $MANAGER"
sed -i "s/<address>.*<\/address>/<address>${MANAGER}<\/address>/" /var/ossec/etc/ossec.conf

echo "[*] Starting Wazuh agent..."
/var/ossec/bin/wazuh-control start

# Keep the container running and show agent logs
tail -f /var/ossec/logs/ossec.log
