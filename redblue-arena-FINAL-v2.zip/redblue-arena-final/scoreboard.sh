#!/bin/bash
# RedBlue Arena — live scoreboard
# Run this in a SECOND Ubuntu terminal window (side-by-side with the attack),
# right from the project folder. It refreshes every 3 seconds.

RED='\033[1;31m'
GREEN='\033[1;32m'
CYAN='\033[1;36m'
YELLOW='\033[1;33m'
BOLD='\033[1m'
NC='\033[0m'

while true; do
  clear
  echo -e "${CYAN}${BOLD}============================================${NC}"
  echo -e "${CYAN}${BOLD}   REDBLUE ARENA — LIVE SCOREBOARD${NC}"
  echo -e "${CYAN}${BOLD}============================================${NC}"
  echo ""

  total=$(curl -s -k -u admin:SecretPassword "https://localhost:9200/wazuh-alerts-*/_count" 2>/dev/null | grep -o '"count":[0-9]*' | grep -o '[0-9]*')
  total=${total:-0}

  high=$(curl -s -k -u admin:SecretPassword "https://localhost:9200/wazuh-alerts-*/_count" \
    -H 'Content-Type: application/json' \
    -d '{"query":{"range":{"rule.level":{"gte":7}}}}' 2>/dev/null | grep -o '"count":[0-9]*' | grep -o '[0-9]*')
  high=${high:-0}

  echo -e "  ${GREEN}${BOLD}Total alerts detected:${NC}   ${BOLD}${total}${NC}"
  echo -e "  ${RED}${BOLD}High-severity alerts:${NC}    ${BOLD}${high}${NC}"
  echo ""
  echo -e "  ${YELLOW}Red Team:${NC}   attacking target.dvwa"
  echo -e "  ${YELLOW}Blue Team:${NC}  rba-agent -> wazuh.manager -> dashboard"
  echo ""
  echo -e "${CYAN}(refreshing every 3s — press Ctrl+C to stop)${NC}"
  sleep 3
done
