#!/bin/bash
echo "Stopping RedBlue Arena..."
docker compose down

read -p "Also delete all data volumes (fresh start next time)? [y/N] " ans
if [[ "$ans" == "y" || "$ans" == "Y" ]]; then
  docker compose down -v
  echo "Volumes removed."
fi
