#!/bin/bash
# RedBlue Arena — clears any blocks Blue Team has put in place on BOTH
# targets, so you can re-run the attack demo fresh.

echo "[*] Clearing blocks on the DVWA agent..."
docker exec rba-wazuh-agent iptables -F 2>/dev/null || true
docker exec rba-wazuh-agent bash -c "echo '' > /etc/hosts.deny" 2>/dev/null || true

echo "[*] Clearing blocks on the Metasploitable2 agent..."
docker exec rba-wazuh-agent2 iptables -F 2>/dev/null || true
docker exec rba-wazuh-agent2 bash -c "echo '' > /etc/hosts.deny" 2>/dev/null || true

echo "[+] Done. Red Team can reach both targets again."
