#!/bin/bash
set -e

echo "=============================================="
echo "  RedBlue Arena — Deployment"
echo "=============================================="
echo ""
echo "NOTE: You will be asked for your Ubuntu/WSL password"
echo "(the one you set when Ubuntu was first installed)."
echo "This is needed for the 'sudo' step below. Nothing will"
echo "show on screen while you type it — that's normal."
echo ""

# 1. Required for the Wazuh Indexer (OpenSearch) to start correctly.
echo "[*] Setting vm.max_map_count=262144..."
sudo sysctl -w vm.max_map_count=262144 || echo "    (skipped — if the indexer fails to start later, run this manually)"

# 2. Generate certificates locally with openssl (no internet dependency).
echo "[*] Generating certificates..."
bash tools/generate-certs.sh

# 3. Build the Kali red team image and bring everything up.
echo "[*] Building and starting all containers (this can take several minutes on first run)..."
docker compose up -d --build

echo ""
echo "=============================================="
echo " Deployment started. Give it 1-2 minutes, then:"
echo " - Wazuh Dashboard : https://localhost   (admin / SecretPassword)"
echo " - DVWA Target     : http://localhost:8080"
echo " - Run the attack  : docker exec -it rba-red-kali bash /root/attack.sh"
echo "=============================================="
