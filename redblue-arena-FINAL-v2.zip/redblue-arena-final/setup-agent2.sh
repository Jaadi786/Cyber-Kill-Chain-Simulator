#!/bin/bash
# RedBlue Arena — configure the second Wazuh agent to monitor
# Metasploitable2's authentication log (for SSH brute-force detection).
# Run this ONCE, after ./deploy.sh has finished and all containers are "Up".
set -e

echo "[*] Adding Metasploitable2 auth log monitoring to the second agent..."
docker exec rba-wazuh-agent2 bash -c "sed -i 's#</ossec_config>#<localfile><log_format>syslog</log_format><location>/msf-logs/auth.log</location></localfile></ossec_config>#' /var/ossec/etc/ossec.conf"

echo "[*] Restarting the agent to apply the change..."
docker exec rba-wazuh-agent2 /var/ossec/bin/wazuh-control restart

echo ""
echo "[+] Done. This agent now watches Metasploitable2's auth log."
echo "    Wazuh's built-in SSH brute-force rules will fire automatically"
echo "    once the attack script's Hydra step runs."
