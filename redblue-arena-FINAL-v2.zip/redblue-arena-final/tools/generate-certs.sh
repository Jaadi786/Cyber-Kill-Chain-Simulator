#!/bin/bash
# RedBlue Arena — certificate generator
# Generates a root CA + one cert per Wazuh node using plain openssl.
# No internet dependency, no Wazuh packaging versions to match.
set -e

OUT=./config/wazuh_indexer_ssl_certs
mkdir -p "$OUT"

TMP=$(mktemp -d)
cd "$TMP"

echo "[*] Generating root CA..."
openssl req -x509 -new -nodes -newkey rsa:2048 \
  -keyout root-ca.key -out root-ca.pem \
  -batch -subj "/OU=Wazuh/O=Wazuh/L=California/" -days 3650 2>/dev/null

gen_node_cert() {
  local name="$1"
  echo "[*] Generating certificate for $name..."
  cat > "$name.conf" <<EOF
[ req ]
prompt = no
default_bits = 2048
default_md = sha256
distinguished_name = req_distinguished_name
x509_extensions = v3_req

[req_distinguished_name]
C = US
L = California
O = Wazuh
OU = Wazuh
CN = $name

[ v3_req ]
authorityKeyIdentifier=keyid,issuer
basicConstraints = CA:FALSE
keyUsage = digitalSignature, nonRepudiation, keyEncipherment, dataEncipherment
subjectAltName = @alt_names

[alt_names]
DNS.1 = $name
EOF
  openssl req -new -nodes -newkey rsa:2048 \
    -keyout "$name-key.pem" -out "$name.csr" \
    -config "$name.conf" 2>/dev/null
  openssl x509 -req -in "$name.csr" \
    -CA root-ca.pem -CAkey root-ca.key -CAcreateserial \
    -out "$name.pem" -extfile "$name.conf" -extensions v3_req -days 3650 2>/dev/null
}

gen_node_cert "wazuh.indexer"
gen_node_cert "wazuh.manager"
gen_node_cert "wazuh.dashboard"

echo "[*] Generating admin certificate..."
openssl genrsa -out admin-key-temp.pem 2048 2>/dev/null
openssl pkcs8 -inform PEM -outform PEM -in admin-key-temp.pem -topk8 -nocrypt -v1 PBE-SHA1-3DES -out admin-key.pem 2>/dev/null
openssl req -new -key admin-key.pem -out admin.csr -batch -subj "/C=US/L=California/O=Wazuh/OU=Wazuh/CN=admin" 2>/dev/null
openssl x509 -days 3650 -req -in admin.csr -CA root-ca.pem -CAkey root-ca.key -CAcreateserial -out admin.pem 2>/dev/null

echo "[*] Copying certificates into place..."
cd - > /dev/null

cp "$TMP/root-ca.pem" "$OUT/"
cp "$TMP/root-ca.pem" "$OUT/root-ca-manager.pem"
cp "$TMP/wazuh.indexer.pem" "$TMP/wazuh.indexer-key.pem" "$OUT/"
cp "$TMP/wazuh.manager.pem" "$TMP/wazuh.manager-key.pem" "$OUT/"
cp "$TMP/wazuh.dashboard.pem" "$TMP/wazuh.dashboard-key.pem" "$OUT/"
cp "$TMP/admin.pem" "$TMP/admin-key.pem" "$OUT/"

rm -rf "$TMP"

echo "[*] Setting permissions..."
chmod -R 744 "$OUT"

echo "[+] Certificates generated successfully in $OUT/"
