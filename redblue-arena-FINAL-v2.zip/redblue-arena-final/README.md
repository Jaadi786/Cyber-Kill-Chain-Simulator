# Cyber Kill-Chain Simulator — RedBlue Arena

A self-contained cyber range that runs on your own laptop: an automated Red
Team (Kali + Metasploit + Nmap + Hydra) attacks **two** deliberately
vulnerable targets, while a Blue Team stack (Wazuh) **detects the attacks
and actively blocks them** — with everything visualized live on a
dashboard.

## What's inside

| Service | Container | Role |
|---|---|---|
| wazuh.manager | `rba-wazuh-manager` | Detection engine + active response (blocking) |
| wazuh.indexer | `rba-wazuh-indexer` | Stores and searches all security events |
| wazuh.dashboard | `rba-wazuh-dashboard` | Live web dashboard (browser) |
| target.dvwa | `rba-target-dvwa` | Target 1: vulnerable web app |
| wazuh.agent | `rba-wazuh-agent` | Watches DVWA and enforces blocks on it |
| target.metasploitable2 | `rba-target-metasploitable2` | Target 2: classic vulnerable Linux box (FTP, SSH, more) |
| wazuh.agent2 | `rba-wazuh-agent2` | Watches Metasploitable2 and enforces blocks on it |
| red.kali | `rba-red-kali` | Red Team attacker (Metasploit + Nmap + Hydra) |

## Requirements

- Docker Desktop with WSL2 integration enabled
- 8 GB RAM minimum, 16 GB recommended, ~15 GB free disk space
- Your Ubuntu/WSL password (for one `sudo` step)

## 1. Deploy

```bash
chmod +x deploy.sh stop.sh setup-agent.sh setup-agent2.sh scoreboard.sh reset-block.sh
./deploy.sh
```

Wait until `docker ps` shows all 8 containers as "Up" (first run takes a
few minutes — Metasploitable2's image is large).

## 2. Connect both agents to their targets' logs (one time only)

```bash
./setup-agent.sh
./setup-agent2.sh
```

## 3. Set up DVWA

Open **http://localhost:8080**, click **"Create / Reset Database"**, then
log in with `admin` / `password`.

## 4. Run the attack (Red Team)

```bash
docker exec -it rba-red-kali bash /root/attack.sh
```

Full sequence:
1. Nmap recon on DVWA
2. Deep vulnerability scan
3. Web path probing
4. SQL injection attempts
5. Metasploit scanner on DVWA
6. Nmap recon on Metasploitable2
7. **Real exploit** — the famous `vsftpd 2.3.4` backdoor, which opens an
   actual remote shell and runs `id` on the target to prove real code
   execution
8. **Brute-force attack** — Hydra guesses SSH credentials on Metasploitable2
9. Blue Team response check — re-tests both targets to show whether they've
   been auto-blocked

**Optional — watch alert counts live in a second terminal window:**
```bash
./scoreboard.sh
```

## 5. Confirm the Blue Team response

- **Dashboard:** open **https://localhost** (`admin` / `SecretPassword`) →
  Threat Hunting → clear any filter → set time range to "Last 24 hours" →
  search `rule.level:>=6`.
- **Proof of the actual blocks:**
  ```bash
  docker exec rba-wazuh-agent iptables -L -n
  docker exec rba-wazuh-agent2 iptables -L -n
  ```
  Both should show a `DROP` rule for the Kali container's IP.

## How the defense works

Wazuh's manager runs two **active response** layers, automatically
triggered by any alert of severity level 6+ from either agent:

1. **`firewall-drop`** — adds an iptables `DROP` rule for the attacker's
   IP (this is what actually cuts off traffic).
2. **`host-deny`** — also records the IP in `/etc/hosts.deny` as a second,
   more traditional layer.

Brute-force detection uses Wazuh's **built-in SSH rules** (no custom rules
needed) — repeated failed logins are automatically recognized and scored.

Both blocks auto-expire after 120 seconds. To reset early and re-run:
```bash
./reset-block.sh
```

## Stop everything

```bash
./stop.sh
```

---

## Troubleshooting

- **`sudo: Authentication failed`** → use your Ubuntu/WSL password, not Windows.
- **Container name already in use** → `docker rm -f $(docker ps -aq)` then `./deploy.sh` again.
- **Manifest/image `not found`** → temporary Docker Hub issue; wait and retry.
- **Indexer keeps restarting** → `sudo sysctl -w vm.max_map_count=262144`
- **No alerts on dashboard after attacking** → make sure `./setup-agent.sh`
  and `./setup-agent2.sh` were both run once; clear dashboard filters;
  widen time range.
- **Config changes (like active response) not taking effect** → do a clean
  redeploy: `docker compose down -v` then `./deploy.sh` again.
- **vsftpd exploit doesn't open a session** → Metasploitable2 needs ~30–60s
  after startup for all services to come up; re-run the attack script if
  this happens on the very first run.
- **Port already in use (443/8080/9200)** → something else is using it;
  stop it or edit the `ports:` mapping in `docker-compose.yml`.

If you hit anything not listed here, copy the exact terminal output and send it.
