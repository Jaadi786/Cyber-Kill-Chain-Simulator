#!/bin/bash
# RedBlue Arena — configure the Wazuh agent to monitor DVWA's Apache logs.
# Run this ONCE, after ./deploy.sh has finished and all containers are "Up".
set -e

echo "[*] Adding DVWA log monitoring to the Wazuh agent..."
docker exec rba-wazuh-agent bash -c "sed -i 's#</ossec_config>#<localfile><log_format>apache</log_format><location>/dvwa-logs/access.log</location></localfile><localfile><log_format>apache</log_format><location>/dvwa-logs/error.log</location></localfile></ossec_config>#' /var/ossec/etc/ossec.conf"

echo "[*] Restarting the agent to apply the change..."
docker exec rba-wazuh-agent /var/ossec/bin/wazuh-control restart

echo ""
echo "[+] Done. The agent now watches DVWA's access/error logs."
echo "    Run the attack script, then check the Wazuh dashboard's"
echo "    Threat Hunting page (remove any 'manager.name' filter first)."
